const Footer = () => {
  return <footer className="px-20 p-10 text-xl font-semibold bg-gray-900">All Rights Reserved &copy; </footer>;
};

export default Footer;
